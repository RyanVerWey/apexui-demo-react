import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ToolbarProps = React.HTMLAttributes<HTMLDivElement> & {
  actions?: React.ReactNode;
  density?: "comfortable" | "compact";
  justify?: "start" | "between" | "end";
  label: string;
  wrap?: boolean;
};

export function Toolbar({
  actions,
  children,
  className,
  density = "comfortable",
  justify = "between",
  label,
  wrap = true,
  ...props
}: ToolbarProps) {
  return (
    <div
      aria-label={label}
      className={classNames(
        "apex-toolbar",
        `apex-toolbar-${density}`,
        `apex-toolbar-${justify}`,
        wrap && "apex-toolbar-wrap",
        className
      )}
      role="toolbar"
      {...props}
    >
      <div className="apex-toolbar-content">{children}</div>
      {actions && <div className="apex-toolbar-actions">{actions}</div>}
    </div>
  );
}
