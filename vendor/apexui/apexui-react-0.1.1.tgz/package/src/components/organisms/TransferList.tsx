import * as React from "react";
import { classNames } from "../../utils/classNames";

export type TransferListItem = {
  disabled?: boolean;
  id: string;
  label: React.ReactNode;
  selected?: boolean;
};

export type TransferListProps = React.HTMLAttributes<HTMLDivElement> & {
  moveAllLeftLabel?: string;
  moveAllRightLabel?: string;
  moveLeftLabel?: string;
  moveRightLabel?: string;
  onMoveAllLeft?: () => void;
  onMoveAllRight?: () => void;
  onMoveLeft?: () => void;
  onMoveRight?: () => void;
  sourceItems: TransferListItem[];
  sourceTitle: React.ReactNode;
  targetItems: TransferListItem[];
  targetTitle: React.ReactNode;
};

export function TransferList({
  className,
  moveAllLeftLabel = "Move all left",
  moveAllRightLabel = "Move all right",
  moveLeftLabel = "Move selected left",
  moveRightLabel = "Move selected right",
  onMoveAllLeft,
  onMoveAllRight,
  onMoveLeft,
  onMoveRight,
  sourceItems,
  sourceTitle,
  targetItems,
  targetTitle,
  ...props
}: TransferListProps) {
  return (
    <div className={classNames("apex-transfer-list", className)} {...props}>
      <TransferListPanel items={sourceItems} title={sourceTitle} />
      <div className="apex-transfer-list-actions" aria-label="Transfer controls">
        <button className="apex-transfer-list-action" onClick={onMoveAllRight} type="button">{moveAllRightLabel}</button>
        <button className="apex-transfer-list-action" onClick={onMoveRight} type="button">{moveRightLabel}</button>
        <button className="apex-transfer-list-action" onClick={onMoveLeft} type="button">{moveLeftLabel}</button>
        <button className="apex-transfer-list-action" onClick={onMoveAllLeft} type="button">{moveAllLeftLabel}</button>
      </div>
      <TransferListPanel items={targetItems} title={targetTitle} />
    </div>
  );
}

function TransferListPanel({ items, title }: { items: TransferListItem[]; title: React.ReactNode }) {
  return (
    <section className="apex-transfer-list-panel">
      <h3 className="apex-transfer-list-title">{title}</h3>
      <ul className="apex-transfer-list-items">
        {items.map((item) => (
          <li className={classNames("apex-transfer-list-item", item.selected && "apex-transfer-list-item-selected")} key={item.id}>
            <label className="apex-transfer-list-option">
              <input className="apex-transfer-list-checkbox" disabled={item.disabled} defaultChecked={item.selected} type="checkbox" />
              <span>{item.label}</span>
            </label>
          </li>
        ))}
      </ul>
    </section>
  );
}
