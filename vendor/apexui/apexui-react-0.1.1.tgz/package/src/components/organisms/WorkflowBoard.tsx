import * as React from "react";
import { classNames } from "../../utils/classNames";

export type WorkflowColumn = {
  id: string;
  items: Array<{ id: string; title: React.ReactNode; meta?: React.ReactNode }>;
  title: React.ReactNode;
};

export type WorkflowBoardProps = React.HTMLAttributes<HTMLDivElement> & {
  columns: WorkflowColumn[];
};

export function WorkflowBoard({ className, columns, ...props }: WorkflowBoardProps) {
  return (
    <div className={classNames("apex-workflow-board", className)} {...props}>
      {columns.map((column) => (
        <section className="apex-workflow-column" key={column.id}>
          <header className="apex-workflow-column-header">
            <strong className="apex-workflow-column-title">{column.title}</strong>
            <span className="apex-workflow-column-count">{column.items.length}</span>
          </header>
          <div className="apex-workflow-items">
            {column.items.map((item) => (
              <article className="apex-workflow-item" key={item.id}>
                <strong className="apex-workflow-item-title">{item.title}</strong>
                {item.meta && <span className="apex-workflow-item-meta">{item.meta}</span>}
              </article>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
