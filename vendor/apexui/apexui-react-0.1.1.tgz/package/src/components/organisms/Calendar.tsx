import * as React from "react";
import { classNames } from "../../utils/classNames";

export type CalendarDay = {
  badge?: React.ReactNode;
  disabled?: boolean;
  id: string;
  label: React.ReactNode;
  muted?: boolean;
  selected?: boolean;
};

export type CalendarProps = React.HTMLAttributes<HTMLDivElement> & {
  days: CalendarDay[];
  label: string;
  monthLabel: React.ReactNode;
  onDaySelect?: (day: CalendarDay) => void;
  weekdays: React.ReactNode[];
};

export function Calendar({ className, days, label, monthLabel, onDaySelect, weekdays, ...props }: CalendarProps) {
  return (
    <section aria-label={label} className={classNames("apex-calendar", className)} {...props}>
      <header className="apex-calendar-header">
        <h3 className="apex-calendar-title">{monthLabel}</h3>
      </header>
      <div className="apex-calendar-weekdays">
        {weekdays.map((weekday, index) => (
          <span className="apex-calendar-weekday" key={index}>
            {weekday}
          </span>
        ))}
      </div>
      <div className="apex-calendar-grid">
        {days.map((day) => (
          <button
            aria-pressed={day.selected}
            className={classNames(
              "apex-calendar-day",
              day.muted && "apex-calendar-day-muted",
              day.selected && "apex-calendar-day-selected"
            )}
            disabled={day.disabled}
            key={day.id}
            onClick={() => onDaySelect?.(day)}
            type="button"
          >
            <span className="apex-calendar-day-label">{day.label}</span>
            {day.badge && <span className="apex-calendar-day-badge">{day.badge}</span>}
          </button>
        ))}
      </div>
    </section>
  );
}
