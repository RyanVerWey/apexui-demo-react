import * as React from "react";
import { classNames } from "../../utils/classNames";

export type SidebarItem = {
  badge?: React.ReactNode;
  disabled?: boolean;
  href?: string;
  icon?: React.ReactNode;
  id: string;
  label: React.ReactNode;
};

export type SidebarProps = React.HTMLAttributes<HTMLElement> & {
  activeId?: string;
  footer?: React.ReactNode;
  heading: React.ReactNode;
  items: SidebarItem[];
  label: string;
  onSelect?: (id: string) => void;
};

export function Sidebar({ activeId, className, footer, heading, items, label, onSelect, ...props }: SidebarProps) {
  return (
    <aside className={classNames("apex-sidebar", className)} {...props}>
      <div className="apex-sidebar-header">
        <h3 className="apex-sidebar-title">{heading}</h3>
      </div>
      <nav aria-label={label} className="apex-sidebar-nav">
        {items.map((item) => {
          const itemContent = (
            <>
              {item.icon && <span className="apex-sidebar-icon" aria-hidden="true">{item.icon}</span>}
              <span className="apex-sidebar-label">{item.label}</span>
              {item.badge && <span className="apex-sidebar-badge">{item.badge}</span>}
            </>
          );
          const itemClassName = classNames("apex-sidebar-item", item.id === activeId && "apex-sidebar-item-active");

          if (item.href) {
            return (
              <a aria-current={item.id === activeId ? "page" : undefined} className={itemClassName} href={item.href} key={item.id}>
                {itemContent}
              </a>
            );
          }

          return (
            <button
              aria-current={item.id === activeId ? "page" : undefined}
              className={itemClassName}
              disabled={item.disabled}
              key={item.id}
              onClick={() => onSelect?.(item.id)}
              type="button"
            >
              {itemContent}
            </button>
          );
        })}
      </nav>
      {footer && <div className="apex-sidebar-footer">{footer}</div>}
    </aside>
  );
}
