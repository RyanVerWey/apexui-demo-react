import * as React from "react";
import { classNames } from "../../utils/classNames";

export type DataGridSortDirection = "asc" | "desc";

export type DataGridColumn = {
  filterable?: boolean;
  header: React.ReactNode;
  key: string;
  render?: (row: DataGridRow) => React.ReactNode;
  sortable?: boolean;
  value?: (row: DataGridRow) => string | number | boolean | null | undefined;
};

export type DataGridRow = Record<string, React.ReactNode>;

export type DataGridProps = React.HTMLAttributes<HTMLDivElement> & {
  caption: string;
  columns: DataGridColumn[];
  defaultFilters?: Record<string, string>;
  defaultPage?: number;
  defaultSortDirection?: DataGridSortDirection;
  defaultSortKey?: string;
  emptyState?: React.ReactNode;
  filterable?: boolean;
  filters?: Record<string, string>;
  onFiltersChange?: (filters: Record<string, string>) => void;
  onPageChange?: (page: number) => void;
  onSortChange?: (key: string, direction: DataGridSortDirection) => void;
  page?: number;
  pageable?: boolean;
  pageSize?: number;
  rows: DataGridRow[];
  sortable?: boolean;
  sortDirection?: DataGridSortDirection;
  sortKey?: string;
};

export function DataGrid({
  caption,
  className,
  columns,
  defaultFilters = {},
  defaultPage = 1,
  defaultSortDirection = "asc",
  defaultSortKey,
  emptyState = "No rows match the current view.",
  filterable = false,
  filters,
  onFiltersChange,
  onPageChange,
  onSortChange,
  page,
  pageable = false,
  pageSize = 10,
  rows,
  sortable = false,
  sortDirection,
  sortKey,
  ...props
}: DataGridProps) {
  const [internalFilters, setInternalFilters] = React.useState(defaultFilters);
  const [internalPage, setInternalPage] = React.useState(defaultPage);
  const [internalSortDirection, setInternalSortDirection] = React.useState(defaultSortDirection);
  const [internalSortKey, setInternalSortKey] = React.useState(defaultSortKey);

  const activeFilters = filters ?? internalFilters;
  const activePage = page ?? internalPage;
  const activeSortDirection = sortDirection ?? internalSortDirection;
  const activeSortKey = sortKey ?? internalSortKey;
  const safePageSize = Math.max(1, pageSize);

  const processedRows = React.useMemo(() => {
    const filtered = rows.filter((row) => columns.every((column) => {
      if (!isFilterable(column, filterable)) return true;
      const query = (activeFilters[column.key] ?? "").trim().toLowerCase();
      if (!query) return true;
      return String(getCellValue(row, column) ?? "").toLowerCase().includes(query);
    }));

    if (!activeSortKey) return filtered;
    const sortColumn = columns.find((column) => column.key === activeSortKey);
    if (!sortColumn || !isSortable(sortColumn, sortable)) return filtered;

    return [...filtered].sort((a, b) => {
      const first = getCellValue(a, sortColumn);
      const second = getCellValue(b, sortColumn);
      const comparison = compareValues(first, second);
      return activeSortDirection === "asc" ? comparison : -comparison;
    });
  }, [activeFilters, activeSortDirection, activeSortKey, columns, filterable, rows, sortable]);

  const totalPages = pageable ? Math.max(1, Math.ceil(processedRows.length / safePageSize)) : 1;
  const clampedPage = Math.min(Math.max(1, activePage), totalPages);
  const visibleRows = pageable ? processedRows.slice((clampedPage - 1) * safePageSize, clampedPage * safePageSize) : processedRows;

  function updateSort(column: DataGridColumn) {
    if (!isSortable(column, sortable)) return;
    const nextDirection = activeSortKey === column.key && activeSortDirection === "asc" ? "desc" : "asc";
    if (sortKey === undefined) setInternalSortKey(column.key);
    if (sortDirection === undefined) setInternalSortDirection(nextDirection);
    if (page === undefined) setInternalPage(1);
    onSortChange?.(column.key, nextDirection);
    onPageChange?.(1);
  }

  function updateFilter(columnKey: string, value: string) {
    const nextFilters = { ...activeFilters, [columnKey]: value };
    if (!value) delete nextFilters[columnKey];
    if (filters === undefined) setInternalFilters(nextFilters);
    if (page === undefined) setInternalPage(1);
    onFiltersChange?.(nextFilters);
    onPageChange?.(1);
  }

  function updatePage(nextPage: number) {
    const safePage = Math.min(Math.max(1, nextPage), totalPages);
    if (page === undefined) setInternalPage(safePage);
    onPageChange?.(safePage);
  }

  return (
    <div className={classNames("apex-data-grid", className)} {...props}>
      <div className="apex-data-grid-toolbar">
        <strong className="apex-data-grid-title">{caption}</strong>
        <span className="apex-data-grid-count">{processedRows.length} rows</span>
      </div>
      <div className="apex-table-container">
        <table className="apex-table">
          <caption className="apex-table-caption">{caption}</caption>
          <thead>
            <tr>{columns.map((column) => (
              <th className="apex-table-header" key={column.key} scope="col">
                {isSortable(column, sortable) ? (
                  <button className="apex-data-grid-sort" type="button" onClick={() => updateSort(column)} aria-label={`Sort by ${headerText(column)}`}>
                    <span>{column.header}</span>
                    <span className="apex-data-grid-sort-indicator">{activeSortKey === column.key ? (activeSortDirection === "asc" ? "Asc" : "Desc") : "Sort"}</span>
                  </button>
                ) : column.header}
              </th>
            ))}</tr>
            {columns.some((column) => isFilterable(column, filterable)) && (
              <tr>
                {columns.map((column) => (
                  <th className="apex-table-filter-cell" key={`${column.key}-filter`} scope="col">
                    {isFilterable(column, filterable) && (
                      <input
                        aria-label={`Filter ${headerText(column)}`}
                        className="apex-data-grid-filter"
                        onChange={(event) => updateFilter(column.key, event.target.value)}
                        placeholder="Filter"
                        type="search"
                        value={activeFilters[column.key] ?? ""}
                      />
                    )}
                  </th>
                ))}
              </tr>
            )}
          </thead>
          <tbody>
            {visibleRows.length > 0 ? visibleRows.map((row, rowIndex) => (
              <tr className="apex-data-grid-row" key={rowIndex}>{columns.map((column) => <td className="apex-table-cell" key={column.key}>{column.render ? column.render(row) : row[column.key]}</td>)}</tr>
            )) : (
              <tr>
                <td className="apex-table-cell apex-data-grid-empty" colSpan={columns.length}>{emptyState}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {pageable && (
        <div className="apex-data-grid-pager" aria-label={`${caption} pagination`}>
          <button className="apex-data-grid-page-button" type="button" onClick={() => updatePage(clampedPage - 1)} disabled={clampedPage <= 1}>Previous</button>
          <span className="apex-data-grid-page-status">Page {clampedPage} of {totalPages}</span>
          <button className="apex-data-grid-page-button" type="button" onClick={() => updatePage(clampedPage + 1)} disabled={clampedPage >= totalPages}>Next</button>
        </div>
      )}
    </div>
  );
}

function isSortable(column: DataGridColumn, sortable: boolean) {
  return column.sortable ?? sortable;
}

function isFilterable(column: DataGridColumn, filterable: boolean) {
  return column.filterable ?? filterable;
}

function getCellValue(row: DataGridRow, column: DataGridColumn) {
  return column.value ? column.value(row) : row[column.key];
}

function compareValues(first: React.ReactNode, second: React.ReactNode) {
  const firstValue = normalizeValue(first);
  const secondValue = normalizeValue(second);
  if (typeof firstValue === "number" && typeof secondValue === "number") return firstValue - secondValue;
  return String(firstValue).localeCompare(String(secondValue), undefined, { numeric: true, sensitivity: "base" });
}

function normalizeValue(value: React.ReactNode) {
  if (typeof value === "number") return value;
  if (typeof value === "string") return value;
  if (typeof value === "boolean") return value ? 1 : 0;
  return value == null ? "" : String(value);
}

function headerText(column: DataGridColumn) {
  return typeof column.header === "string" ? column.header : column.key;
}
