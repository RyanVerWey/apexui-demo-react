import * as React from "react";
import { classNames } from "../../utils/classNames";

export type DataTableColumn<Row> = {
  key: keyof Row;
  header: string;
};

export type DataTableProps<Row extends Record<string, React.ReactNode>> = {
  caption: string;
  columns: Array<DataTableColumn<Row>>;
  rows: Row[];
  className?: string;
};

export function DataTable<Row extends Record<string, React.ReactNode>>({
  caption,
  className,
  columns,
  rows
}: DataTableProps<Row>) {
  return (
    <div className={classNames("apex-table-container", className)}>
      <table className="apex-table">
        <caption className="apex-table-caption">{caption}</caption>
        <thead className="apex-table-head">
          <tr className="apex-table-row">
            {columns.map((column) => (
              <th className="apex-table-header" key={String(column.key)} scope="col">
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="apex-table-body">
          {rows.map((row, rowIndex) => (
            <tr className="apex-table-row" key={rowIndex}>
              {columns.map((column) => (
                <td className="apex-table-cell" key={String(column.key)}>
                  {row[column.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
