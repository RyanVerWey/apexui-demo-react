import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ImageListItem = {
  alt: string;
  caption?: React.ReactNode;
  src: string;
};

export type ImageListProps = React.HTMLAttributes<HTMLDivElement> & {
  columns?: "two" | "three" | "four";
  items: ImageListItem[];
};

export function ImageList({ className, columns = "three", items, ...props }: ImageListProps) {
  return (
    <div className={classNames("apex-image-list", `apex-image-list-${columns}`, className)} {...props}>
      {items.map((item) => (
        <figure className="apex-image-list-item" key={item.src}>
          <img className="apex-image-list-image" src={item.src} alt={item.alt} />
          {item.caption && <figcaption className="apex-image-list-caption">{item.caption}</figcaption>}
        </figure>
      ))}
    </div>
  );
}
