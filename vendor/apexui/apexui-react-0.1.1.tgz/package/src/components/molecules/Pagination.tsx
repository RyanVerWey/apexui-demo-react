import * as React from "react";
import { classNames } from "../../utils/classNames";

export type PaginationProps = React.HTMLAttributes<HTMLElement> & {
  count: number;
  label?: string;
  onPageChange?: (page: number) => void;
  page: number;
};

export function Pagination({ className, count, label = "Pagination", onPageChange, page, ...props }: PaginationProps) {
  const pages = Array.from({ length: count }, (_, index) => index + 1);

  return (
    <nav aria-label={label} className={classNames("apex-pagination", className)} {...props}>
      {pages.map((item) => (
        <button
          aria-current={item === page ? "page" : undefined}
          className="apex-pagination-item"
          key={item}
          type="button"
          onClick={() => onPageChange?.(item)}
        >
          {item}
        </button>
      ))}
    </nav>
  );
}
