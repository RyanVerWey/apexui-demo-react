import * as React from "react";
import { classNames } from "../../utils/classNames";

export type SpeedDialAction = {
  disabled?: boolean;
  icon?: React.ReactNode;
  id: string;
  label: React.ReactNode;
  onSelect?: () => void;
};

export type SpeedDialProps = React.HTMLAttributes<HTMLDivElement> & {
  actions: SpeedDialAction[];
  label: string;
  open?: boolean;
};

export function SpeedDial({ actions, className, label, open = false, ...props }: SpeedDialProps) {
  return (
    <div className={classNames("apex-speed-dial", open && "apex-speed-dial-open", className)} {...props}>
      {open && (
        <div className="apex-speed-dial-actions">
          {actions.map((action) => (
            <button className="apex-speed-dial-action" disabled={action.disabled} key={action.id} onClick={action.onSelect} type="button">
              {action.icon && <span className="apex-speed-dial-action-icon" aria-hidden="true">{action.icon}</span>}
              <span>{action.label}</span>
            </button>
          ))}
        </div>
      )}
      <button className="apex-speed-dial-trigger" type="button" aria-expanded={open} aria-label={label}>
        +
      </button>
    </div>
  );
}
