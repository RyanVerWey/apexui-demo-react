import * as React from "react";
import { classNames } from "../../utils/classNames";

export type TreeViewItem = {
  children?: TreeViewItem[];
  id: string;
  label: React.ReactNode;
};

export type TreeViewProps = React.HTMLAttributes<HTMLUListElement> & {
  items: TreeViewItem[];
  label: string;
};

export function TreeView({ className, items, label, ...props }: TreeViewProps) {
  return (
    <ul aria-label={label} className={classNames("apex-tree", className)} role="tree" {...props}>
      {items.map((item) => (
        <TreeNode item={item} key={item.id} />
      ))}
    </ul>
  );
}

function TreeNode({ item }: { item: TreeViewItem }) {
  return (
    <li className="apex-tree-item" role="treeitem" aria-expanded={item.children ? "true" : undefined}>
      <span className="apex-tree-label">{item.label}</span>
      {item.children && (
        <ul className="apex-tree-group" role="group">
          {item.children.map((child) => (
            <TreeNode item={child} key={child.id} />
          ))}
        </ul>
      )}
    </li>
  );
}
