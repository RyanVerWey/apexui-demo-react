import * as React from "react";
import { classNames } from "../../utils/classNames";

export type MenuItem = {
  disabled?: boolean;
  id: string;
  label: React.ReactNode;
  onSelect?: () => void;
};

export type MenuProps = React.HTMLAttributes<HTMLDivElement> & {
  items: MenuItem[];
  label: React.ReactNode;
};

export function Menu({ className, items, label, ...props }: MenuProps) {
  const [open, setOpen] = React.useState(false);
  const menuRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!open) {
      return;
    }

    function handlePointerDown(event: PointerEvent) {
      if (!menuRef.current?.contains(event.target as Node)) {
        setOpen(false);
      }
    }

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
      }
    }

    document.addEventListener("pointerdown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [open]);

  return (
    <div className={classNames("apex-menu", className)} ref={menuRef} {...props}>
      <button aria-expanded={open} aria-haspopup="menu" className="apex-menu-trigger" type="button" onClick={() => setOpen((value) => !value)}>
        {label}
      </button>
      {open && (
        <div className="apex-menu-content" role="menu">
          {items.map((item) => (
            <button
              className="apex-menu-item"
              disabled={item.disabled}
              key={item.id}
              role="menuitem"
              type="button"
              onClick={() => {
                item.onSelect?.();
                setOpen(false);
              }}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
