import * as React from "react";
import { classNames } from "../../utils/classNames";

export type TimelineEvent = {
  description?: React.ReactNode;
  id: string;
  label: React.ReactNode;
  meta?: React.ReactNode;
};

export type TimelineProps = React.HTMLAttributes<HTMLOListElement> & {
  events: TimelineEvent[];
};

export function Timeline({ className, events, ...props }: TimelineProps) {
  return (
    <ol className={classNames("apex-timeline", className)} {...props}>
      {events.map((event) => (
        <li className="apex-timeline-item" key={event.id}>
          <span className="apex-timeline-marker" />
          <span className="apex-timeline-content">
            <span className="apex-timeline-label">{event.label}</span>
            {event.description && <span className="apex-timeline-description">{event.description}</span>}
            {event.meta && <span className="apex-timeline-meta">{event.meta}</span>}
          </span>
        </li>
      ))}
    </ol>
  );
}
