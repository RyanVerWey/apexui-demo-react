import * as React from "react";
import { classNames } from "../../utils/classNames";

export type CarouselItem = {
  content: React.ReactNode;
  id: string;
  label: React.ReactNode;
};

export type CarouselProps = React.HTMLAttributes<HTMLDivElement> & {
  activeIndex?: number;
  defaultActiveIndex?: number;
  items: CarouselItem[];
  label: string;
  nextLabel?: string;
  onIndexChange?: (index: number) => void;
  previousLabel?: string;
};

export function Carousel({
  activeIndex,
  className,
  defaultActiveIndex = 0,
  items,
  label,
  nextLabel = "Next",
  onIndexChange,
  previousLabel = "Previous",
  ...props
}: CarouselProps) {
  const [internalIndex, setInternalIndex] = React.useState(defaultActiveIndex);
  const selectedIndex = clampIndex(activeIndex ?? internalIndex, items.length);
  const selectedItem = items[selectedIndex];

  function setIndex(nextIndex: number) {
    const clamped = clampIndex(nextIndex, items.length);
    if (activeIndex === undefined) {
      setInternalIndex(clamped);
    }
    onIndexChange?.(clamped);
  }

  if (items.length === 0) {
    return null;
  }

  return (
    <section aria-label={label} aria-roledescription="carousel" className={classNames("apex-carousel", className)} {...props}>
      <div className="apex-carousel-viewport">
        <div aria-live="polite" className="apex-carousel-slide">
          {selectedItem.content}
        </div>
      </div>
      <div className="apex-carousel-controls">
        <button className="apex-carousel-control" onClick={() => setIndex(selectedIndex - 1)} type="button">
          {previousLabel}
        </button>
        <div className="apex-carousel-dots" role="tablist" aria-label={`${label} slides`}>
          {items.map((item, index) => (
            <button
              aria-label={`${item.label}`}
              aria-selected={index === selectedIndex}
              className="apex-carousel-dot"
              key={item.id}
              onClick={() => setIndex(index)}
              role="tab"
              type="button"
            />
          ))}
        </div>
        <button className="apex-carousel-control" onClick={() => setIndex(selectedIndex + 1)} type="button">
          {nextLabel}
        </button>
      </div>
    </section>
  );
}

function clampIndex(index: number, length: number) {
  if (length <= 0) {
    return 0;
  }

  return (index + length) % length;
}
