import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ListItem = {
  description?: React.ReactNode;
  id: string;
  label: React.ReactNode;
  meta?: React.ReactNode;
};

export type ListProps = React.HTMLAttributes<HTMLUListElement | HTMLOListElement> & {
  items: ListItem[];
  ordered?: boolean;
};

export function List({ className, items, ordered = false, ...props }: ListProps) {
  const Component = ordered ? "ol" : "ul";

  return (
    <Component className={classNames("apex-list", ordered && "apex-list-ordered", className)} {...props}>
      {items.map((item) => (
        <li className="apex-list-item" key={item.id}>
          <div className="apex-list-content">
            <span className="apex-list-label">{item.label}</span>
            {item.description && <span className="apex-list-description">{item.description}</span>}
          </div>
          {item.meta && <span className="apex-list-meta">{item.meta}</span>}
        </li>
      ))}
    </Component>
  );
}
