import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ModalProps = React.HTMLAttributes<HTMLDivElement> & {
  actions?: React.ReactNode;
  closeLabel?: string;
  contained?: boolean;
  description?: React.ReactNode;
  onClose?: () => void;
  open?: boolean;
  title: React.ReactNode;
};

export function Modal({
  actions,
  children,
  className,
  closeLabel = "Close",
  contained = false,
  description,
  onClose,
  open = false,
  title,
  ...props
}: ModalProps) {
  if (!open) {
    return null;
  }

  return (
    <div className={classNames("apex-modal-layer", contained && "apex-modal-layer-contained", className)} {...props}>
      <div className="apex-modal" role="dialog" aria-modal={contained ? undefined : true} aria-labelledby="apex-modal-title">
        <header className="apex-modal-header">
          <div className="apex-modal-heading">
            <h2 className="apex-modal-title" id="apex-modal-title">{title}</h2>
            {description && <p className="apex-modal-description">{description}</p>}
          </div>
          {onClose && (
            <button className="apex-modal-close" onClick={onClose} type="button" aria-label={closeLabel}>
              x
            </button>
          )}
        </header>
        <div className="apex-modal-body">{children}</div>
        {actions && <footer className="apex-modal-actions">{actions}</footer>}
      </div>
    </div>
  );
}
