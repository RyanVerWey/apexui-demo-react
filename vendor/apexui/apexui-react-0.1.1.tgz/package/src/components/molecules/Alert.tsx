import * as React from "react";
import { classNames } from "../../utils/classNames";

export type AlertProps = React.HTMLAttributes<HTMLDivElement> & {
  tone?: "info" | "success" | "warning" | "danger";
  title?: string;
};

export function Alert({ children, className, title, tone = "info", ...props }: AlertProps) {
  return (
    <div className={classNames("apex-alert", `apex-alert-${tone}`, className)} role="status" {...props}>
      {title && <strong className="apex-alert-title">{title}</strong>}
      <div className="apex-alert-body">{children}</div>
    </div>
  );
}
