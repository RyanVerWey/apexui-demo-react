import * as React from "react";
import { classNames } from "../../utils/classNames";

export type AppBarProps = React.HTMLAttributes<HTMLElement> & {
  actions?: React.ReactNode;
  navigation?: React.ReactNode;
  title: React.ReactNode;
};

export function AppBar({ actions, children, className, navigation, title, ...props }: AppBarProps) {
  return (
    <header className={classNames("apex-app-bar", className)} {...props}>
      <div className="apex-app-bar-main">
        <strong className="apex-app-bar-title">{title}</strong>
        {children}
      </div>
      {navigation && <nav className="apex-app-bar-nav">{navigation}</nav>}
      {actions && <div className="apex-app-bar-actions">{actions}</div>}
    </header>
  );
}
