import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ChartDatum = {
  label: React.ReactNode;
  value: number;
};

export type ChartProps = React.HTMLAttributes<HTMLDivElement> & {
  data: ChartDatum[];
  label: string;
};

export function Chart({ className, data, label, ...props }: ChartProps) {
  return (
    <div aria-label={label} className={classNames("apex-chart", className)} role="img" {...props}>
      {data.map((item, index) => (
        <div className="apex-chart-row" key={index}>
          <span className="apex-chart-label">{item.label}</span>
          <span className="apex-chart-track">
            <span className={classNames("apex-chart-bar", `apex-chart-value-${bucketValue(item.value)}`)} />
          </span>
          <span className="apex-chart-value">{item.value}%</span>
        </div>
      ))}
    </div>
  );
}

function bucketValue(value: number) {
  return Math.max(0, Math.min(100, Math.round(value / 10) * 10));
}
