import * as React from "react";
import { classNames } from "../../utils/classNames";

export type BreadcrumbItem = {
  current?: boolean;
  href?: string;
  label: React.ReactNode;
};

export type BreadcrumbsProps = React.HTMLAttributes<HTMLElement> & {
  items: BreadcrumbItem[];
  label?: string;
};

export function Breadcrumbs({ className, items, label = "Breadcrumb", ...props }: BreadcrumbsProps) {
  return (
    <nav aria-label={label} className={classNames("apex-breadcrumbs", className)} {...props}>
      <ol className="apex-breadcrumbs-list">
        {items.map((item, index) => (
          <li className="apex-breadcrumbs-item" key={index}>
            {item.href && !item.current ? (
              <a className="apex-breadcrumbs-link" href={item.href}>{item.label}</a>
            ) : (
              <span aria-current={item.current ? "page" : undefined} className="apex-breadcrumbs-current">{item.label}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
