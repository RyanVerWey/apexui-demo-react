import * as React from "react";
import { classNames } from "../../utils/classNames";

export type AccordionItem = {
  content: React.ReactNode;
  id: string;
  title: React.ReactNode;
};

export type AccordionProps = React.HTMLAttributes<HTMLDivElement> & {
  items: AccordionItem[];
};

export function Accordion({ className, items, ...props }: AccordionProps) {
  return (
    <div className={classNames("apex-accordion", className)} {...props}>
      {items.map((item) => (
        <details className="apex-accordion-item" key={item.id}>
          <summary className="apex-accordion-trigger">{item.title}</summary>
          <div className="apex-accordion-panel">{item.content}</div>
        </details>
      ))}
    </div>
  );
}
