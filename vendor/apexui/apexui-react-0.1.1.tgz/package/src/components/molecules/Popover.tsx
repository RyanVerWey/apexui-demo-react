import * as React from "react";
import { classNames } from "../../utils/classNames";

export type PopoverProps = Omit<React.HTMLAttributes<HTMLDivElement>, "content"> & {
  content: React.ReactNode;
  open?: boolean;
  placement?: "top" | "bottom" | "start" | "end";
  trigger: React.ReactNode;
};

export function Popover({ className, content, open = false, placement = "bottom", trigger, ...props }: PopoverProps) {
  return (
    <div className={classNames("apex-popover", `apex-popover-${placement}`, className)} {...props}>
      <div className="apex-popover-trigger">{trigger}</div>
      {open && (
        <div className="apex-popover-panel" role="dialog">
          {content}
        </div>
      )}
    </div>
  );
}
