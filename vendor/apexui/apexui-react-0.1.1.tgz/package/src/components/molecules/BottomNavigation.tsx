import * as React from "react";
import { classNames } from "../../utils/classNames";

export type BottomNavigationItem = {
  disabled?: boolean;
  icon?: React.ReactNode;
  id: string;
  label: React.ReactNode;
};

export type BottomNavigationProps = React.HTMLAttributes<HTMLElement> & {
  activeId?: string;
  items: BottomNavigationItem[];
  label: string;
  onChange?: (id: string) => void;
};

export function BottomNavigation({ activeId, className, items, label, onChange, ...props }: BottomNavigationProps) {
  return (
    <nav aria-label={label} className={classNames("apex-bottom-navigation", className)} {...props}>
      {items.map((item) => (
        <button
          aria-current={item.id === activeId ? "page" : undefined}
          className="apex-bottom-navigation-item"
          disabled={item.disabled}
          key={item.id}
          onClick={() => onChange?.(item.id)}
          type="button"
        >
          {item.icon && <span className="apex-bottom-navigation-icon" aria-hidden="true">{item.icon}</span>}
          <span className="apex-bottom-navigation-label">{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
