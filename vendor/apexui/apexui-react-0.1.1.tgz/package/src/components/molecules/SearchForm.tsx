import * as React from "react";
import { Button } from "../atoms/Button";
import { TextInput } from "../atoms/TextInput";
import { classNames } from "../../utils/classNames";

export type SearchFormProps = {
  label: string;
  placeholder?: string;
  submitLabel?: string;
  onSubmit: (query: string) => void;
  className?: string;
};

export function SearchForm({ className, label, placeholder, submitLabel = "Search", onSubmit }: SearchFormProps) {
  const [query, setQuery] = React.useState("");

  return (
    <form
      className={classNames("apex-search-form", className)}
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit(query);
      }}
    >
      <TextInput
        label={label}
        placeholder={placeholder}
        value={query}
        onChange={(event) => setQuery(event.currentTarget.value)}
      />
      <Button type="submit">{submitLabel}</Button>
    </form>
  );
}
