import * as React from "react";
import { classNames } from "../../utils/classNames";

export type PaperProps = React.HTMLAttributes<HTMLElement> & {
  as?: "article" | "aside" | "div" | "section";
  elevation?: "none" | "sm" | "md";
};

export function Paper({ as = "section", children, className, elevation = "sm", ...props }: PaperProps) {
  return React.createElement(
    as,
    {
      className: classNames("apex-paper", `apex-paper-${elevation}`, className),
      ...props
    },
    children
  );
}
