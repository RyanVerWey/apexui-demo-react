import * as React from "react";
import { classNames } from "../../utils/classNames";

export type SnackbarProps = React.HTMLAttributes<HTMLDivElement> & {
  action?: React.ReactNode;
  open?: boolean;
  tone?: "info" | "success" | "warning" | "danger";
};

export function Snackbar({ action, children, className, open = true, tone = "info", ...props }: SnackbarProps) {
  if (!open) {
    return null;
  }

  return (
    <div aria-live="polite" className={classNames("apex-snackbar", `apex-snackbar-${tone}`, className)} role="status" {...props}>
      <div className="apex-snackbar-message">{children}</div>
      {action && <div className="apex-snackbar-action">{action}</div>}
    </div>
  );
}
