import * as React from "react";
import { classNames } from "../../utils/classNames";

export type BackdropProps = React.HTMLAttributes<HTMLDivElement> & {
  contained?: boolean;
  open?: boolean;
};

export function Backdrop({ children, className, contained = false, open = false, ...props }: BackdropProps) {
  if (!open) {
    return null;
  }

  return (
    <div className={classNames("apex-backdrop", contained && "apex-backdrop-contained", className)} {...props}>
      {children}
    </div>
  );
}
