import * as React from "react";
import { classNames } from "../../utils/classNames";

export type MenuBarItem = {
  current?: boolean;
  id: string;
  label: React.ReactNode;
  onSelect?: () => void;
};

export type MenuBarProps = React.HTMLAttributes<HTMLDivElement> & {
  items: MenuBarItem[];
  label?: string;
};

export function MenuBar({ className, items, label = "Menu", ...props }: MenuBarProps) {
  return (
    <div aria-label={label} className={classNames("apex-menubar", className)} role="menubar" {...props}>
      {items.map((item) => (
        <button aria-current={item.current ? "page" : undefined} className="apex-menubar-item" key={item.id} role="menuitem" type="button" onClick={item.onSelect}>
          {item.label}
        </button>
      ))}
    </div>
  );
}
