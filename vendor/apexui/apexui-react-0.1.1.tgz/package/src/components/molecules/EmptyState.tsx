import * as React from "react";
import { classNames } from "../../utils/classNames";

export type EmptyStateProps = React.HTMLAttributes<HTMLElement> & {
  action?: React.ReactNode;
  align?: "start" | "center";
  description?: React.ReactNode;
  icon?: React.ReactNode;
  secondaryAction?: React.ReactNode;
  title: React.ReactNode;
};

export function EmptyState({
  action,
  align = "center",
  children,
  className,
  description,
  icon,
  secondaryAction,
  title,
  ...props
}: EmptyStateProps) {
  return (
    <section className={classNames("apex-empty-state", `apex-empty-state-${align}`, className)} {...props}>
      {icon && <div className="apex-empty-state-icon" aria-hidden="true">{icon}</div>}
      <div className="apex-empty-state-copy">
        <h3 className="apex-empty-state-title">{title}</h3>
        {description && <p className="apex-empty-state-description">{description}</p>}
        {children}
      </div>
      {(action || secondaryAction) && (
        <div className="apex-empty-state-actions">
          {action}
          {secondaryAction}
        </div>
      )}
    </section>
  );
}
