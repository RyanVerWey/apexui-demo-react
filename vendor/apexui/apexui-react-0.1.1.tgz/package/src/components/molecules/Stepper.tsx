import * as React from "react";
import { classNames } from "../../utils/classNames";

export type StepperStep = {
  description?: React.ReactNode;
  id: string;
  label: React.ReactNode;
};

export type StepperProps = React.HTMLAttributes<HTMLOListElement> & {
  activeIndex?: number;
  steps: StepperStep[];
};

export function Stepper({ activeIndex = 0, className, steps, ...props }: StepperProps) {
  return (
    <ol className={classNames("apex-stepper", className)} {...props}>
      {steps.map((step, index) => (
        <li className={classNames("apex-stepper-step", index <= activeIndex && "apex-stepper-step-active")} key={step.id}>
          <span className="apex-stepper-marker">{index + 1}</span>
          <span className="apex-stepper-content">
            <span className="apex-stepper-label">{step.label}</span>
            {step.description && <span className="apex-stepper-description">{step.description}</span>}
          </span>
        </li>
      ))}
    </ol>
  );
}
