import * as React from "react";
import { classNames } from "../../utils/classNames";

export type TabItem = {
  id: string;
  label: string;
};

export type TabsProps = {
  items: TabItem[];
  activeId: string;
  label: string;
  onChange: (id: string) => void;
  className?: string;
};

export function Tabs({ activeId, className, items, label, onChange }: TabsProps) {
  return (
    <div aria-label={label} className={classNames("apex-tabs", className)} role="tablist">
      {items.map((item) => (
        <button
          aria-selected={item.id === activeId}
          className="apex-tabs-tab"
          key={item.id}
          onClick={() => onChange(item.id)}
          role="tab"
          type="button"
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}
