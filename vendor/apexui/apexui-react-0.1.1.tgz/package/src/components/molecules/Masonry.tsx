import * as React from "react";
import { classNames } from "../../utils/classNames";

export type MasonryProps = React.HTMLAttributes<HTMLDivElement> & {
  columns?: "two" | "three" | "four";
};

export function Masonry({ className, columns = "three", ...props }: MasonryProps) {
  return <div className={classNames("apex-masonry", `apex-masonry-${columns}`, className)} {...props} />;
}
