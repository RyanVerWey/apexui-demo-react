import * as React from "react";
import { classNames } from "../../utils/classNames";

export type CardProps = React.HTMLAttributes<HTMLElement> & {
  title?: string;
  eyebrow?: string;
  fill?: boolean;
};

export function Card({ children, className, eyebrow, fill = false, title, ...props }: CardProps) {
  return (
    <article className={classNames("apex-card", fill && "apex-card-fill", className)} {...props}>
      {(eyebrow || title) && (
        <header className="apex-card-header">
          {eyebrow && <span className="apex-card-eyebrow">{eyebrow}</span>}
          {title && <h3 className="apex-card-title">{title}</h3>}
        </header>
      )}
      <div className="apex-card-body">{children}</div>
    </article>
  );
}
