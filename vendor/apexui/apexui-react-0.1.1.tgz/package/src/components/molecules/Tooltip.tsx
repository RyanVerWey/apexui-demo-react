import * as React from "react";
import { classNames } from "../../utils/classNames";

export type TooltipProps = React.HTMLAttributes<HTMLSpanElement> & {
  content: React.ReactNode;
};

export function Tooltip({ children, className, content, ...props }: TooltipProps) {
  const tooltipId = React.useId();

  return (
    <span className={classNames("apex-tooltip", className)} {...props}>
      <span aria-describedby={tooltipId} className="apex-tooltip-trigger" tabIndex={0}>
        {children}
      </span>
      <span className="apex-tooltip-content" id={tooltipId} role="tooltip">
        {content}
      </span>
    </span>
  );
}
