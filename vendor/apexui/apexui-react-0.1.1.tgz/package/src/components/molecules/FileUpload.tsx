import * as React from "react";
import { classNames } from "../../utils/classNames";

export type FileUploadFile = {
  meta?: React.ReactNode;
  name: React.ReactNode;
};

export type FileUploadProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "children" | "onChange" | "type"> & {
  actionLabel?: React.ReactNode;
  description?: React.ReactNode;
  files?: FileUploadFile[];
  label: React.ReactNode;
  onFilesChange?: (files: File[]) => void;
};

export function FileUpload({
  actionLabel = "Choose files",
  className,
  description,
  disabled,
  files = [],
  label,
  multiple,
  onFilesChange,
  ...props
}: FileUploadProps) {
  return (
    <div className={classNames("apex-file-upload", className)}>
      <label className={classNames("apex-file-upload-dropzone", disabled && "apex-file-upload-disabled")}>
        <input
          className="apex-file-upload-input"
          disabled={disabled}
          multiple={multiple}
          onChange={(event) => onFilesChange?.(Array.from(event.currentTarget.files ?? []))}
          type="file"
          {...props}
        />
        <span className="apex-file-upload-content">
          <span className="apex-file-upload-label">{label}</span>
          {description && <span className="apex-file-upload-description">{description}</span>}
        </span>
        <span className="apex-file-upload-action">{actionLabel}</span>
      </label>
      {files.length > 0 && (
        <ul className="apex-file-upload-list">
          {files.map((file, index) => (
            <li className="apex-file-upload-file" key={index}>
              <span className="apex-file-upload-file-name">{file.name}</span>
              {file.meta && <span className="apex-file-upload-file-meta">{file.meta}</span>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
