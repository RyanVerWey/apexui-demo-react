import * as React from "react";
import { classNames } from "../../utils/classNames";

export type DialogProps = React.HTMLAttributes<HTMLDivElement> & {
  actions?: React.ReactNode;
  description?: React.ReactNode;
  onClose?: () => void;
  open?: boolean;
  title: React.ReactNode;
};

export function Dialog({ actions, children, className, description, onClose, open = false, title, ...props }: DialogProps) {
  const titleId = React.useId();
  const descriptionId = React.useId();

  if (!open) {
    return null;
  }

  return (
    <div className="apex-dialog-backdrop">
      <section
        aria-describedby={description ? descriptionId : undefined}
        aria-labelledby={titleId}
        aria-modal="true"
        className={classNames("apex-dialog", className)}
        role="dialog"
        {...props}
      >
        <header className="apex-dialog-header">
          <div className="apex-dialog-heading">
            <h2 className="apex-dialog-title" id={titleId}>
              {title}
            </h2>
            {description && (
              <p className="apex-dialog-description" id={descriptionId}>
                {description}
              </p>
            )}
          </div>
          {onClose && (
            <button aria-label="Close dialog" className="apex-dialog-close" type="button" onClick={onClose}>
              x
            </button>
          )}
        </header>
        <div className="apex-dialog-body">{children}</div>
        {actions && <footer className="apex-dialog-actions">{actions}</footer>}
      </section>
    </div>
  );
}
