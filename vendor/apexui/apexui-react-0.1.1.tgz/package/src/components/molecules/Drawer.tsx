import * as React from "react";
import { classNames } from "../../utils/classNames";

export type DrawerProps = React.HTMLAttributes<HTMLElement> & {
  onClose?: () => void;
  open?: boolean;
  side?: "left" | "right";
  title: React.ReactNode;
};

export function Drawer({ children, className, onClose, open = false, side = "left", title, ...props }: DrawerProps) {
  if (!open) {
    return null;
  }

  return (
    <aside aria-label={typeof title === "string" ? title : undefined} className={classNames("apex-drawer", `apex-drawer-${side}`, className)} {...props}>
      <header className="apex-drawer-header">
        <strong className="apex-drawer-title">{title}</strong>
        {onClose && <button aria-label="Close drawer" className="apex-drawer-close" type="button" onClick={onClose}>x</button>}
      </header>
      <div className="apex-drawer-body">{children}</div>
    </aside>
  );
}
