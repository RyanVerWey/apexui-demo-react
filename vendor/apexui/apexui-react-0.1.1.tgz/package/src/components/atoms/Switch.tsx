import * as React from "react";
import { classNames } from "../../utils/classNames";

export type SwitchProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> & {
  label: string;
  description?: string;
};

export function Switch({ className, description, label, ...props }: SwitchProps) {
  return (
    <label className={classNames("apex-switch", className)}>
      <input className="apex-switch-input" role="switch" type="checkbox" {...props} />
      <span className="apex-switch-track" aria-hidden="true">
        <span className="apex-switch-thumb" />
      </span>
      <span className="apex-switch-content">
        <span className="apex-switch-label">{label}</span>
        {description && <span className="apex-switch-description">{description}</span>}
      </span>
    </label>
  );
}
