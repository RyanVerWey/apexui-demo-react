import * as React from "react";
import { classNames } from "../../utils/classNames";

export type SliderProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "id" | "type"> & {
  id?: string;
  label: string;
};

export function Slider({ className, id, label, max = 100, min = 0, value, defaultValue, ...props }: SliderProps) {
  const generatedId = React.useId();
  const inputId = id ?? generatedId;
  const displayValue = value ?? defaultValue ?? min;

  return (
    <label className={classNames("apex-slider", className)} htmlFor={inputId}>
      <span className="apex-slider-header">
        <span className="apex-field-label">{label}</span>
        <output className="apex-slider-value">{displayValue}</output>
      </span>
      <input
        className="apex-slider-control"
        defaultValue={defaultValue}
        id={inputId}
        max={max}
        min={min}
        type="range"
        value={value}
        {...props}
      />
    </label>
  );
}
