import * as React from "react";
import { classNames } from "../../utils/classNames";

export type BoxProps = React.HTMLAttributes<HTMLDivElement> & {
  padding?: "none" | "sm" | "md" | "lg";
  surface?: "none" | "surface" | "subtle";
};

export function Box({ className, padding = "md", surface = "none", ...props }: BoxProps) {
  return (
    <div
      className={classNames("apex-box", `apex-box-padding-${padding}`, `apex-box-${surface}`, className)}
      {...props}
    />
  );
}
