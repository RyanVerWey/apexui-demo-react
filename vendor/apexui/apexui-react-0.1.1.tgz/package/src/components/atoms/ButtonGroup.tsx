import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ButtonGroupProps = React.HTMLAttributes<HTMLDivElement> & {
  label: string;
};

export function ButtonGroup({ className, label, ...props }: ButtonGroupProps) {
  return <div aria-label={label} className={classNames("apex-button-group", className)} role="group" {...props} />;
}
