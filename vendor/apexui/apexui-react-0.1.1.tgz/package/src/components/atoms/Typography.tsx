import * as React from "react";
import { classNames } from "../../utils/classNames";

export type TypographyProps = React.HTMLAttributes<HTMLElement> & {
  as?: "p" | "span" | "strong" | "small" | "h1" | "h2" | "h3" | "h4";
  variant?: "display" | "title" | "subtitle" | "body" | "caption";
};

export function Typography({
  as = "p",
  children,
  className,
  variant = "body",
  ...props
}: TypographyProps) {
  return React.createElement(
    as,
    {
      className: classNames("apex-typography", `apex-typography-${variant}`, className),
      ...props
    },
    children
  );
}
