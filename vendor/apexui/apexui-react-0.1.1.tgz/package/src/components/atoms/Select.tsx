import * as React from "react";
import { classNames } from "../../utils/classNames";

export type SelectOption = {
  label: string;
  value: string;
};

export type SelectProps = Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "id"> & {
  id?: string;
  label: string;
  options: SelectOption[];
  hint?: string;
};

export function Select({ className, hint, id, label, options, ...props }: SelectProps) {
  const generatedId = React.useId();
  const selectId = id ?? generatedId;
  const descriptionId = hint ? `${selectId}-description` : undefined;

  return (
    <label className={classNames("apex-field", className)} htmlFor={selectId}>
      <span className="apex-field-label">{label}</span>
      <select aria-describedby={descriptionId} className="apex-field-control apex-select-control" id={selectId} {...props}>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {hint && (
        <span className="apex-field-description" id={descriptionId}>
          {hint}
        </span>
      )}
    </label>
  );
}
