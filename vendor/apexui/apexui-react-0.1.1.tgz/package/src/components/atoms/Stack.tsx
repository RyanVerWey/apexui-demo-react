import * as React from "react";
import { classNames } from "../../utils/classNames";

export type StackProps = React.HTMLAttributes<HTMLDivElement> & {
  align?: "start" | "center" | "stretch";
  direction?: "row" | "column";
  gap?: "sm" | "md" | "lg";
};

export function Stack({ align = "stretch", className, direction = "column", gap = "md", ...props }: StackProps) {
  return <div className={classNames("apex-stack", `apex-stack-${direction}`, `apex-stack-${gap}`, `apex-stack-align-${align}`, className)} {...props} />;
}
