import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ToggleOption = {
  label: string;
  value: string;
};

export type ToggleGroupProps = Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> & {
  label: string;
  options: ToggleOption[];
  value?: string;
  onValueChange?: (value: string) => void;
};

export function ToggleGroup({ className, label, onValueChange, options, value, ...props }: ToggleGroupProps) {
  return (
    <div aria-label={label} className={classNames("apex-toggle-group", className)} role="group" {...props}>
      {options.map((option) => (
        <button
          aria-pressed={value === option.value}
          className={classNames("apex-toggle", value === option.value && "apex-toggle-selected")}
          key={option.value}
          onClick={() => onValueChange?.(option.value)}
          type="button"
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}
