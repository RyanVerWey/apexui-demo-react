import * as React from "react";
import { classNames } from "../../utils/classNames";

export type DatePickerProps = React.InputHTMLAttributes<HTMLInputElement> & {
  hint?: string;
  label: string;
};

export function DatePicker({ className, hint, id, label, ...props }: DatePickerProps) {
  const generatedId = React.useId();
  const fieldId = id ?? generatedId;
  const descriptionId = hint ? `${fieldId}-description` : undefined;

  return (
    <label className={classNames("apex-field", className)} htmlFor={fieldId}>
      <span className="apex-field-label">{label}</span>
      <input aria-describedby={descriptionId} className="apex-field-control" id={fieldId} type="date" {...props} />
      {hint && <span className="apex-field-description" id={descriptionId}>{hint}</span>}
    </label>
  );
}
