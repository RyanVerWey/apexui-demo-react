import * as React from "react";
import { classNames } from "../../utils/classNames";

export type LinkProps = React.AnchorHTMLAttributes<HTMLAnchorElement> & {
  variant?: "inline" | "standalone" | "subtle";
};

export function Link({ className, variant = "inline", ...props }: LinkProps) {
  return <a className={classNames("apex-link", `apex-link-${variant}`, className)} {...props} />;
}
