import * as React from "react";
import { classNames } from "../../utils/classNames";

export type RadioOption = {
  label: string;
  value: string;
  description?: string;
};

export type RadioGroupProps = Omit<React.FieldsetHTMLAttributes<HTMLFieldSetElement>, "onChange"> & {
  label: string;
  name: string;
  options: RadioOption[];
  value?: string;
  onValueChange?: (value: string) => void;
};

export function RadioGroup({ className, label, name, onValueChange, options, value, ...props }: RadioGroupProps) {
  return (
    <fieldset className={classNames("apex-radio-group", className)} {...props}>
      <legend className="apex-radio-group-label">{label}</legend>
      <span className="apex-radio-group-options">
        {options.map((option) => (
          <label className="apex-radio" key={option.value}>
            <input
              checked={value === option.value}
              className="apex-radio-input"
              name={name}
              onChange={() => onValueChange?.(option.value)}
              type="radio"
              value={option.value}
            />
            <span className="apex-radio-content">
              <span className="apex-radio-label">{option.label}</span>
              {option.description && <span className="apex-radio-description">{option.description}</span>}
            </span>
          </label>
        ))}
      </span>
    </fieldset>
  );
}
