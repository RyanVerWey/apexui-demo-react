import * as React from "react";
import { classNames } from "../../utils/classNames";

export type RatingProps = Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> & {
  label: string;
  max?: number;
  value?: number;
  onValueChange?: (value: number) => void;
};

export function Rating({ className, label, max = 5, onValueChange, value = 0, ...props }: RatingProps) {
  return (
    <div aria-label={label} className={classNames("apex-rating", className)} role="radiogroup" {...props}>
      {Array.from({ length: max }, (_, index) => {
        const ratingValue = index + 1;
        return (
          <button
            aria-checked={value === ratingValue}
            aria-label={`${ratingValue} of ${max}`}
            className={classNames("apex-rating-item", ratingValue <= value && "apex-rating-item-active")}
            key={ratingValue}
            onClick={() => onValueChange?.(ratingValue)}
            role="radio"
            type="button"
          >
            {ratingValue}
          </button>
        );
      })}
    </div>
  );
}
