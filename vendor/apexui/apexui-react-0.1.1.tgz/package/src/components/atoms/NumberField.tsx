import * as React from "react";
import { classNames } from "../../utils/classNames";

export type NumberFieldProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "id" | "type"> & {
  id?: string;
  label: string;
  hint?: string;
  error?: string;
};

export function NumberField({ className, error, hint, id, label, ...props }: NumberFieldProps) {
  const generatedId = React.useId();
  const inputId = id ?? generatedId;
  const descriptionId = error || hint ? `${inputId}-description` : undefined;

  return (
    <label className={classNames("apex-field", error && "apex-field-invalid", className)} htmlFor={inputId}>
      <span className="apex-field-label">{label}</span>
      <input
        aria-describedby={descriptionId}
        aria-invalid={Boolean(error) || undefined}
        className="apex-field-control apex-number-field-control"
        id={inputId}
        type="number"
        {...props}
      />
      {(error || hint) && (
        <span className={classNames("apex-field-description", error && "apex-field-error")} id={descriptionId}>
          {error ?? hint}
        </span>
      )}
    </label>
  );
}
