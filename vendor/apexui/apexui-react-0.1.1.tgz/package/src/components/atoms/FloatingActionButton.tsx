import * as React from "react";
import { classNames } from "../../utils/classNames";

export type FloatingActionButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  size?: "sm" | "md" | "lg";
  variant?: "primary" | "secondary";
};

export function FloatingActionButton({
  className,
  size = "md",
  type = "button",
  variant = "primary",
  ...props
}: FloatingActionButtonProps) {
  return (
    <button
      className={classNames("apex-fab", `apex-fab-${variant}`, `apex-fab-${size}`, className)}
      type={type}
      {...props}
    />
  );
}
