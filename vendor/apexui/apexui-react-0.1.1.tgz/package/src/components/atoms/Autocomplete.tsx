import * as React from "react";
import { classNames } from "../../utils/classNames";

export type AutocompleteProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "id" | "list"> & {
  id?: string;
  label: string;
  options: string[];
  hint?: string;
};

export function Autocomplete({ className, defaultValue, hint, id, label, onChange, options, value, ...props }: AutocompleteProps) {
  const generatedId = React.useId();
  const inputId = id ?? generatedId;
  const listId = `${inputId}-options`;
  const descriptionId = hint ? `${inputId}-description` : undefined;
  const inputRef = React.useRef<HTMLInputElement>(null);
  const [isOpen, setIsOpen] = React.useState(false);
  const [internalValue, setInternalValue] = React.useState(defaultValue ? String(defaultValue) : "");
  const inputValue = value === undefined ? internalValue : String(value);
  const filteredOptions = options.filter((option) => option.toLowerCase().includes(inputValue.toLowerCase()));

  function selectOption(option: string) {
    if (value === undefined) {
      setInternalValue(option);
    }

    if (inputRef.current) {
      inputRef.current.value = option;
      inputRef.current.dispatchEvent(new Event("input", { bubbles: true }));
    }

    setIsOpen(false);
  }

  return (
    <div className={classNames("apex-field", "apex-autocomplete", className)}>
      <label className="apex-field-label" htmlFor={inputId}>{label}</label>
      <input
        aria-autocomplete="list"
        aria-controls={listId}
        aria-describedby={descriptionId}
        aria-expanded={isOpen && filteredOptions.length > 0}
        className="apex-field-control"
        id={inputId}
        onBlur={() => window.setTimeout(() => setIsOpen(false), 120)}
        onChange={(event) => {
          if (value === undefined) {
            setInternalValue(event.currentTarget.value);
          }
          setIsOpen(true);
          onChange?.(event);
        }}
        onFocus={() => setIsOpen(true)}
        ref={inputRef}
        role="combobox"
        value={value === undefined ? internalValue : value}
        {...props}
      />
      {isOpen && filteredOptions.length > 0 && (
        <div className="apex-autocomplete-listbox" id={listId} role="listbox">
          {filteredOptions.map((option) => (
            <button
              aria-selected={option === inputValue}
              className="apex-autocomplete-option"
              key={option}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => selectOption(option)}
              role="option"
              type="button"
            >
              {option}
            </button>
          ))}
        </div>
      )}
      {hint && (
        <span className="apex-field-description" id={descriptionId}>
          {hint}
        </span>
      )}
    </div>
  );
}
