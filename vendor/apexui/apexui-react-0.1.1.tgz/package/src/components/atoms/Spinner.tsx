import * as React from "react";
import { classNames } from "../../utils/classNames";

export type SpinnerProps = React.HTMLAttributes<HTMLSpanElement> & {
  label?: string;
  size?: "sm" | "md" | "lg";
};

export function Spinner({ className, label = "Loading", size = "md", ...props }: SpinnerProps) {
  return (
    <span
      aria-label={label}
      className={classNames("apex-spinner", `apex-spinner-${size}`, className)}
      role="status"
      {...props}
    />
  );
}
