import * as React from "react";
import { classNames } from "../../utils/classNames";

export type DividerProps = React.HTMLAttributes<HTMLDivElement> & {
  decorative?: boolean;
  label?: string;
  orientation?: "horizontal" | "vertical";
};

export function Divider({
  className,
  decorative = true,
  label,
  orientation = "horizontal",
  ...props
}: DividerProps) {
  return (
    <div
      aria-orientation={orientation}
      className={classNames("apex-divider", `apex-divider-${orientation}`, label && "apex-divider-labeled", className)}
      role={decorative ? "presentation" : "separator"}
      {...props}
    >
      {label && <span className="apex-divider-label">{label}</span>}
    </div>
  );
}
