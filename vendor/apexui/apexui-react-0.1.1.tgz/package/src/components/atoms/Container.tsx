import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ContainerProps = React.HTMLAttributes<HTMLDivElement> & {
  size?: "sm" | "md" | "lg" | "full";
};

export function Container({ className, size = "lg", ...props }: ContainerProps) {
  return <div className={classNames("apex-container", `apex-container-${size}`, className)} {...props} />;
}
