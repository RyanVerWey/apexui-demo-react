import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "danger";
  size?: "sm" | "md" | "lg";
  fullWidth?: boolean;
};

export function Button({
  className,
  fullWidth = false,
  size = "md",
  variant = "primary",
  ...props
}: ButtonProps) {
  return (
    <button
      className={classNames(
        "apex-button",
        `apex-button-${variant}`,
        `apex-button-${size}`,
        fullWidth && "apex-button-full-width",
        className
      )}
      {...props}
    />
  );
}
