import * as React from "react";
import { classNames } from "../../utils/classNames";

export type TextareaProps = Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, "id"> & {
  id?: string;
  label: string;
  hint?: string;
  error?: string;
};

export function Textarea({ className, error, hint, id, label, rows = 4, ...props }: TextareaProps) {
  const generatedId = React.useId();
  const inputId = id ?? generatedId;
  const descriptionId = error || hint ? `${inputId}-description` : undefined;

  return (
    <label className={classNames("apex-field", error && "apex-field-invalid", className)} htmlFor={inputId}>
      <span className="apex-field-label">{label}</span>
      <textarea
        aria-describedby={descriptionId}
        aria-invalid={Boolean(error) || undefined}
        className="apex-field-control apex-textarea-control"
        id={inputId}
        rows={rows}
        {...props}
      />
      {(error || hint) && (
        <span className={classNames("apex-field-description", error && "apex-field-error")} id={descriptionId}>
          {error ?? hint}
        </span>
      )}
    </label>
  );
}
