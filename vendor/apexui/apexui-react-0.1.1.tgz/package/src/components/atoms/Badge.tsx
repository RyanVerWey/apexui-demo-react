import * as React from "react";
import { classNames } from "../../utils/classNames";

export type BadgeProps = React.HTMLAttributes<HTMLSpanElement> & {
  tone?: "neutral" | "info" | "success" | "warning" | "danger";
};

export function Badge({ className, tone = "neutral", ...props }: BadgeProps) {
  return <span className={classNames("apex-badge", `apex-badge-${tone}`, className)} {...props} />;
}
