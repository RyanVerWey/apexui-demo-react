import * as React from "react";
import { classNames } from "../../utils/classNames";

export type AvatarProps = React.HTMLAttributes<HTMLSpanElement> & {
  alt?: string;
  initials?: string;
  size?: "sm" | "md" | "lg";
  src?: string;
};

export function Avatar({ alt = "", className, initials, size = "md", src, ...props }: AvatarProps) {
  return (
    <span className={classNames("apex-avatar", `apex-avatar-${size}`, className)} {...props}>
      {src ? <img className="apex-avatar-image" src={src} alt={alt} /> : <span className="apex-avatar-initials">{initials}</span>}
    </span>
  );
}
