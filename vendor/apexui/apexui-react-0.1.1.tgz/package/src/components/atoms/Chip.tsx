import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ChipProps = React.HTMLAttributes<HTMLSpanElement> & {
  selected?: boolean;
};

export function Chip({ className, selected = false, ...props }: ChipProps) {
  return <span className={classNames("apex-chip", selected && "apex-chip-selected", className)} {...props} />;
}
