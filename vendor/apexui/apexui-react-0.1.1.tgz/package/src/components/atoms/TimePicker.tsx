import * as React from "react";
import { classNames } from "../../utils/classNames";
import { Icon } from "./Icon";

export type TimePickerProps = React.InputHTMLAttributes<HTMLInputElement> & {
  hint?: string;
  label: string;
};

export function TimePicker({ className, hint, id, label, ...props }: TimePickerProps) {
  const generatedId = React.useId();
  const fieldId = id ?? generatedId;
  const descriptionId = hint ? `${fieldId}-description` : undefined;

  return (
    <label className={classNames("apex-field", className)} htmlFor={fieldId}>
      <span className="apex-field-label">{label}</span>
      <span className="apex-field-picker-shell">
        <input aria-describedby={descriptionId} className="apex-field-control apex-field-picker-control" id={fieldId} type="time" {...props} />
        <span aria-hidden="true" className="apex-field-picker-icon">
          <Icon name="clock" size="sm" />
        </span>
      </span>
      {hint && <span className="apex-field-description" id={descriptionId}>{hint}</span>}
    </label>
  );
}
