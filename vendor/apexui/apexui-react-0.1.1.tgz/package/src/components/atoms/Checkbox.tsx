import * as React from "react";
import { classNames } from "../../utils/classNames";

export type CheckboxProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> & {
  label: string;
  description?: string;
};

export function Checkbox({ className, description, label, ...props }: CheckboxProps) {
  return (
    <label className={classNames("apex-checkbox", className)}>
      <input className="apex-checkbox-input" type="checkbox" {...props} />
      <span className="apex-checkbox-content">
        <span className="apex-checkbox-label">{label}</span>
        {description && <span className="apex-checkbox-description">{description}</span>}
      </span>
    </label>
  );
}
