import * as React from "react";
import { classNames } from "../../utils/classNames";

export type SkeletonProps = React.HTMLAttributes<HTMLDivElement> & {
  label?: string;
  size?: "sm" | "md" | "lg";
  variant?: "text" | "rectangular" | "circle";
};

export function Skeleton({ className, label = "Loading", size = "md", variant = "text", ...props }: SkeletonProps) {
  return (
    <div
      aria-label={label}
      className={classNames("apex-skeleton", `apex-skeleton-${variant}`, `apex-skeleton-${size}`, className)}
      role="status"
      {...props}
    />
  );
}
