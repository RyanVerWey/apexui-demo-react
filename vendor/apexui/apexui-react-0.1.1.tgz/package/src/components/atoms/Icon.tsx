import * as React from "react";
import { classNames } from "../../utils/classNames";
import { iconNodes, iconPaths } from "./iconData";

export { iconCategories, iconLibraryItems, iconNodes, iconPaths } from "./iconData";
export type { IconCategory, IconName } from "./iconData";

export type IconProps = React.SVGAttributes<SVGSVGElement> & {
  name: keyof typeof iconPaths;
  size?: "sm" | "md" | "lg";
  title?: string;
  decorative?: boolean;
};

export function Icon({ className, decorative = true, name, size = "md", title, ...props }: IconProps) {
  const titleId = React.useId();
  const nodes = iconNodes[name] ?? iconNodes.sparkle;

  return (
    <svg
      aria-hidden={decorative ? true : undefined}
      aria-labelledby={!decorative && title ? titleId : undefined}
      aria-label={!decorative && !title ? name : undefined}
      className={classNames("apex-icon", `apex-icon-${size}`, className)}
      fill="none"
      focusable="false"
      role={!decorative ? "img" : undefined}
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      viewBox="0 0 24 24"
      {...props}
    >
      {!decorative && title ? <title id={titleId}>{title}</title> : null}
      {nodes.map(([tag, attrs], index) =>
        React.createElement(tag as keyof React.JSX.IntrinsicElements, { ...(attrs as React.SVGProps<SVGElement>), key: index })
      )}
    </svg>
  );
}
