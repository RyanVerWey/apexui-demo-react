import * as React from "react";
import { classNames } from "../../utils/classNames";

export type ProgressProps = React.HTMLAttributes<HTMLDivElement> & {
  label: string;
  value: number;
};

export function Progress({ className, label, value, ...props }: ProgressProps) {
  const safeValue = Math.max(0, Math.min(100, value));
  const bucket = Math.round(safeValue / 10) * 10;
  const valueLabel = `${safeValue}%`;

  return (
    <div
      aria-label={label}
      aria-valuemax={100}
      aria-valuemin={0}
      aria-valuenow={safeValue}
      className={classNames("apex-progress", className)}
      role="progressbar"
      {...props}
    >
      <span className="apex-progress-header">
        <span className="apex-progress-label">{label}</span>
        <span className="apex-progress-value">{valueLabel}</span>
      </span>
      <span className="apex-progress-track">
        <span className={classNames("apex-progress-indicator", `apex-progress-value-${bucket}`)} />
      </span>
    </div>
  );
}
