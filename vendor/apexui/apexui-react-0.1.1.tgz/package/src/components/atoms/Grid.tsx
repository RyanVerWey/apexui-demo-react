import * as React from "react";
import { classNames } from "../../utils/classNames";

export type GridProps = React.HTMLAttributes<HTMLDivElement> & {
  align?: "start" | "center" | "stretch";
  columns?: "auto" | "two" | "three" | "four";
  gap?: "none" | "sm" | "md" | "lg";
};

export function Grid({ align = "stretch", className, columns = "auto", gap = "md", ...props }: GridProps) {
  return <div className={classNames("apex-grid", `apex-grid-${columns}`, `apex-grid-gap-${gap}`, `apex-grid-align-${align}`, className)} {...props} />;
}
